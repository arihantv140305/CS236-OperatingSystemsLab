# Lab 2 - Shell Solutions

```
├── question_shell.pdf : Problem Statement
├── shell-code_resources.tgz : Resources
├── solutions_1-7 : Solutions Warm up
│   ├── 1.c
│   ├── 2.c
│   ├── 3.c
│   ├── 6.c
│   └── 7.c
└── solutions_shell : Solutions  making a shell
    ├── my_shell_part_a.c : Solutions part-wise using pgid
    ├── my_shell_part_b.c : Solutions part-wise using pgid
    ├── my_shell_part_c.c : Solutions part-wise using pgid
    ├── my_shell_part_d.c : Solutions part-wise using pgid
    ├── my_shell_part_e.c : Solutions part-wise using pgid
    └── shell_arrays.c : Solution for shell using arrays

3 directories, 13 files
```
